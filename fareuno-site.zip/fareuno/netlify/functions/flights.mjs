// Vercel serverless function. Provider is chosen with the FLIGHT_PROVIDER env var:
//   demo (default)  -> clearly labelled sample fares, no key needed
//   duffel          -> live offers via Duffel (set DUFFEL_TOKEN; test tokens are free)
const AIRLINES=["IndiGo","Air India","Emirates","Vistara","Qatar Airways","Thai Airways","Singapore Airlines","British Airways"];
const hhmm=m=>String(Math.floor(m/60)%24).padStart(2,"0")+":"+String(m%60).padStart(2,"0");
function demo(from,to,date){
  let s=[...(from+to+date)].reduce((a,c)=>a*31+c.charCodeAt(0)>>>0,7);
  const rnd=()=>(s=(s*1664525+1013904223)>>>0)/4294967296;
  const base=3500+Math.floor(rnd()*9000);
  return Array.from({length:6},(_,i)=>{
    const dep=360+Math.floor(rnd()*900),dur=180+Math.floor(rnd()*360),stops=rnd()<.35?1:0;
    return{airline:AIRLINES[Math.floor(rnd()*AIRLINES.length)],from,to,stops,
      depart:hhmm(dep),arrive:hhmm(dep+dur),duration:Math.floor(dur/60)+"h "+(dur%60)+"m",
      price:Math.round((base+i*420+stops*-900+rnd()*800)/10)*10};
  }).sort((a,b)=>a.price-b.price);
}
async function duffel(q){
  const r=await fetch("https://api.duffel.com/air/offer_requests?return_offers=true",{method:"POST",
    headers:{Authorization:"Bearer "+process.env.DUFFEL_TOKEN,"Duffel-Version":"v2","Content-Type":"application/json"},
    body:JSON.stringify({data:{slices:[{origin:q.from,destination:q.to,departure_date:q.date}],
      passengers:Array.from({length:+q.adults||1},()=>({type:"adult"})),cabin_class:q.cabin||"economy"}})});
  const j=await r.json();if(!r.ok)throw new Error("provider");
  return j.data.offers.slice(0,15).map(o=>{const sg=o.slices[0].segments;return{
    airline:o.owner.name,from:q.from,to:q.to,stops:sg.length-1,
    depart:sg[0].departing_at.slice(11,16),arrive:sg[sg.length-1].arriving_at.slice(11,16),
    duration:(o.slices[0].duration||"").replace("PT","").toLowerCase(),price:Math.round(+o.total_amount),currency:o.total_currency}});
}

export default async (req) => {
  const q=Object.fromEntries(new URL(req.url).searchParams);
  const json=(b,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{"content-type":"application/json","cache-control":"public, s-maxage=300, stale-while-revalidate=600"}});
  const env=(k)=>globalThis.Netlify?.env?.get(k)??process.env[k];
  if(!/^[A-Z]{3}$/.test(q.from||"")||!/^[A-Z]{3}$/.test(q.to||"")||!/^\d{4}-\d{2}-\d{2}$/.test(q.date||""))
    return json({error:"Invalid search. Please check airports and date."},400);
  try{
    if(env("FLIGHT_PROVIDER")==="duffel"&&env("DUFFEL_TOKEN")){
      process.env.DUFFEL_TOKEN=env("DUFFEL_TOKEN");
      const offers=await duffel(q);return json({offers,currency:offers[0]?.currency||"INR"});
    }
    return json({demo:true,currency:"INR",offers:demo(q.from,q.to,q.date)});
  }catch(e){return json({error:"Fares are temporarily unavailable. Please try again."},502)}
};
