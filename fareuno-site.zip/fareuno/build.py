import json, os, datetime
SITE=os.environ.get("SITE_URL","https://fareuno.com").rstrip("/")
NAME="Fareuno"; TODAY=datetime.date.today().isoformat()
pages=[]  # (path, priority)

def ld(*objs): return "".join(f'<script type="application/ld+json">{json.dumps(o,ensure_ascii=False)}</script>' for o in objs)
def crumbs(items):
    return {"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":i+1,"name":n,"item":SITE+u} for i,(n,u) in enumerate(items)]}
def crumb_html(items):
    return '<nav class="crumbs wrap" aria-label="Breadcrumb">'+" › ".join(f'<a href="{u}">{n}</a>' if i<len(items)-1 else n for i,(n,u) in enumerate(items))+"</nav>"

def page(path,title,desc,body,extra="",prio="0.7",noindex=False,og="website"):
    url=SITE+path
    head=f'''<!doctype html><html lang="en-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><meta name="description" content="{desc}"><link rel="canonical" href="{url}">
<meta name="robots" content="{'noindex,follow' if noindex else 'index,follow,max-image-preview:large'}"><meta name="theme-color" content="#0f3d33">
<meta property="og:type" content="{og}"><meta property="og:title" content="{title}"><meta property="og:description" content="{desc}"><meta property="og:url" content="{url}"><meta property="og:site_name" content="{NAME}"><meta property="og:image" content="{SITE}/assets/og.svg">
<meta name="twitter:card" content="summary_large_image"><link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/assets/style.css">{extra}</head><body>
<a class="skip" href="#main">Skip to content</a>
<header class="site"><div class="wrap"><a class="logo" href="/">Fare<b>uno</b></a><nav aria-label="Main"><a href="/flights">Flights</a><a href="/destinations">Destinations</a><a href="/guides">Travel guides</a><a href="/about">About</a><a class="btn" href="/#search">Search flights</a></nav></div></header>
<main id="main">{body}</main>
<footer><div class="wrap"><div class="cols"><div><h4>{NAME}</h4><p>Compare flights, find flexible dates and book with confidence. Built for travellers from India and beyond.</p></div>
<div><h4>Explore</h4><ul><li><a href="/flights">Flight search</a></li><li><a href="/destinations">Destinations</a></li><li><a href="/guides">Travel guides</a></li></ul></div>
<div><h4>Company</h4><ul><li><a href="/about">About</a></li><li><a href="/contact">Contact</a></li><li><a href="/privacy">Privacy policy</a></li><li><a href="/terms">Terms of use</a></li></ul></div></div>
<p style="margin-top:30px">© {datetime.date.today().year} {NAME}. Fares and availability change quickly and are confirmed at booking.</p></div></footer>
<script src="/assets/app.js" defer></script></body></html>'''
    fp=("index.html" if path=="/" else path.strip("/")+".html")
    os.makedirs(os.path.dirname(fp) or ".",exist_ok=True); open(fp,"w",encoding="utf-8").write(head)
    if not noindex and path!="/404": pages.append((path,prio))

SEARCH='''<form id="search" class="search wrap" aria-label="Flight search"><div><label for="from">From</label><input id="from" name="from" list="airports" placeholder="Delhi (DEL)" value="Delhi (DEL)" autocomplete="off" required></div>
<div><label for="to">To</label><input id="to" name="to" list="airports" placeholder="Dubai (DXB)" autocomplete="off" required></div>
<div><label for="date">Depart</label><input id="date" name="date" type="date" required></div>
<div><label for="ret">Return (optional)</label><input id="ret" name="ret" type="date"></div>
<div><label for="adults">Travellers</label><select id="adults" name="adults"><option>1</option><option>2</option><option>3</option><option>4</option></select></div>
<div><label for="cabin">Cabin</label><select id="cabin" name="cabin"><option value="economy">Economy</option><option value="premium_economy">Premium economy</option><option value="business">Business</option></select></div>
<button class="btn go" type="submit">Search flights</button><datalist id="airports"></datalist></form>'''

DEST=[
 ("dubai","Dubai","DXB","UAE","Delhi to Dubai flights","About 3h 30m – 4h non-stop","November to March, when daytime temperatures are comfortable","Dubai pairs skyline views, desert safaris, beaches and some of the best shopping in the Gulf. It is one of the most popular short-haul international trips from India, with frequent non-stop services every day.",["Go up the Burj Khalifa at sunset, then watch the Dubai Fountain.","Book a desert safari with dune driving and a camp dinner.","Wander Al Fahidi and the old souks, and take an abra across the Creek.","Spend a beach day at JBR or Kite Beach."],"Check current visa and entry rules for your passport before you book; they change and depend on nationality."),
 ("bangkok","Bangkok","BKK","Thailand","Delhi to Bangkok flights","About 4h 15m – 4h 45m non-stop","November to February, which is the cooler, drier season","Bangkok rewards short trips: temples, river life, street food and rooftop bars sit within a few metro stops of each other. It is also the easiest gateway to Phuket, Krabi and Chiang Mai.",["See Wat Pho and the Grand Palace early, before the crowds and heat.","Eat your way through Yaowarat (Chinatown) after dark.","Take a long-tail boat through the Thonburi canals.","Shop Chatuchak Weekend Market, then cool off in a mall."],"Entry requirements for Indian passport holders have changed several times; confirm the current rule on the official Thai government site."),
 ("london","London","LHR","United Kingdom","Delhi to London flights","About 9h – 10h 30m non-stop","May to September for long days and mild weather","London works for first-timers and repeat visitors alike: world-class museums (many free), royal parks, theatre and markets. Non-stop flights from Delhi are frequent, and one-stop options via the Gulf can be cheaper.",["Spend a day on the South Bank: Tate Modern, Borough Market, Tower Bridge.","Visit the British Museum and the National Gallery, both free to enter.","Catch a West End show with day-of tickets.","Day trip to Oxford, Cambridge or Windsor by train."],"UK visitor visas require advance application and processing time varies, so apply well before you pay for non-refundable flights."),
 ("singapore","Singapore","SIN","Singapore","Delhi to Singapore flights","About 5h 30m – 6h non-stop","February to April for slightly drier weather, though it is a year-round destination","Singapore is clean, compact and easy to get around. Gardens by the Bay, hawker centres, Sentosa and Little India make it a strong choice for families and first-time international travellers.",["See the Supertree Grove light show at Gardens by the Bay.","Eat at Maxwell or Lau Pa Sat hawker centres.","Spend a day at Sentosa or Universal Studios.","Explore Little India and Kampong Glam on foot."],"Check the current entry requirements for your passport and any arrival card needed before departure."),
]
FAQ_HOME=[("How does Fareuno find flight prices?","You search by route and date and we show available fares from our flight data providers, sorted by price. The final price and rules are confirmed at booking."),
("Can I search flexible dates?","Yes. Try several nearby dates; fares often differ noticeably between weekdays and weekends."),
("Do I need an account to search?","No. You can search and compare without signing up."),
("How do I get help with a booking?","Use the contact page and include your route and travel dates. We reply by email.")]

# HOME
faq_html="".join(f"<details><summary>{q}</summary><p>{a}</p></details>" for q,a in FAQ_HOME)
routes="".join(f'<a class="card link" href="/flights?from=DEL&to={c}&adults=1&cabin=economy"><span class="tag">{n}</span><h3 style="margin-top:12px">Delhi → {d}</h3><p class="muted">{t}</p><span class="btn ghost">See fares</span></a>' for (s,d,c,n,_,t,*_x) in [(x[0],x[1],x[2],x[3],x[4],x[5]) for x in DEST])
page("/",f"{NAME} – Compare Flights from India & Find Cheap Fares",
 "Compare flights from Delhi, Mumbai and other Indian cities. Search flexible dates, see clear prices and plan your trip with our destination and booking guides.",
 f'''<section class="hero"><div class="wrap"><p class="eyebrow">Flights, simplified</p><h1>Find the fare.<br>Skip the fuss.</h1><p class="lead">Compare flights from India to the world in seconds, with clear prices and guides written to help you book well.</p></div></section>
<div class="wrap">{SEARCH}</div>
<section><div class="wrap"><h2>Popular routes from Delhi</h2><p class="muted">Tap a route to see today’s fares.</p><div class="grid">{routes}</div></div></section>
<section class="alt"><div class="wrap"><h2>Why travellers use {NAME}</h2><div class="grid"><div class="card"><h3>Clear pricing</h3><p>Results are sorted by price with stops and duration side by side, so comparing takes seconds.</p></div><div class="card"><h3>Built for flexibility</h3><p>Change dates quickly and spot cheaper days instead of re-entering everything.</p></div><div class="card"><h3>Guides that help</h3><p>Visa reminders, best seasons and booking checklists for the routes Indians fly most.</p></div></div></div></section>
<section><div class="wrap"><h2>Frequently asked questions</h2>{faq_html}</div></section>''',
 extra=ld({"@context":"https://schema.org","@type":"Organization","name":NAME,"url":SITE,"logo":SITE+"/assets/favicon.svg"},
 {"@context":"https://schema.org","@type":"WebSite","name":NAME,"url":SITE,"potentialAction":{"@type":"SearchAction","target":SITE+"/flights?to={to}","query-input":"required name=to"}},
 {"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":q,"acceptedAnswer":{"@type":"Answer","text":a}} for q,a in FAQ_HOME]}),prio="1.0")

# FLIGHTS
page("/flights","Flight Search – Compare Fares from India | Fareuno","Search and compare flights by route and date. See prices, stops and durations for popular routes from Delhi, Mumbai, Bengaluru and more.",
 f'''{crumb_html([("Home","/"),("Flights","/flights")])}<section style="padding-top:10px"><div class="wrap">{SEARCH}<div style="margin-top:30px"><h1 style="font-size:2rem">Flight results</h1><div id="results"><p class="muted">Enter your route and dates above to see fares.</p></div></div></div></section>''',
 extra=ld(crumbs([("Home","/"),("Flights","/flights")])),prio="0.9")

# DESTINATIONS
cards="".join(f'<a class="card link" href="/destinations/{s}"><span class="tag">{n}</span><h2 style="font-size:1.5rem;margin-top:10px">{d}</h2><p class="muted">{t}</p></a>' for s,d,c,n,h,t,*_ in DEST)
page("/destinations","Destinations from India – Flight Guides | Fareuno","Plan your trip with flight times, best seasons and things to do for Dubai, Bangkok, London and Singapore from Delhi.",
 f'{crumb_html([("Home","/"),("Destinations","/destinations")])}<section style="padding-top:10px"><div class="wrap"><h1>Destinations</h1><p class="muted" style="max-width:640px">Flight times, best seasons and what to do, for the routes Indian travellers book most.</p><div class="grid" style="margin-top:30px">{cards}</div></div></section>',
 extra=ld(crumbs([("Home","/"),("Destinations","/destinations")])),prio="0.8")
for s,d,c,n,h,t,best,intro,todo,note in DEST:
    items=[("Home","/"),("Destinations","/destinations"),(d,f"/destinations/{s}")]
    faq=[(f"How long is the flight from Delhi to {d}?",f"{t}. Duration varies by airline and whether the route is non-stop."),(f"When is the best time to visit {d}?",f"{best[0].upper()+best[1:]}."),(f"Do I need a visa for {d}?",note)]
    body=f'''{crumb_html(items)}<section style="padding-top:10px"><div class="wrap"><article><h1>{h}</h1><p class="lead">{intro}</p>
<p><a class="btn" href="/flights?from=DEL&to={c}&adults=1&cabin=economy">Search Delhi → {d} fares</a></p>
<h2>Flight time and airlines</h2><p>{t}. Several carriers fly this route; compare non-stop and one-stop options, since one-stop itineraries are sometimes cheaper but add hours to the journey.</p>
<h2>Best time to go</h2><p>{best[0].upper()+best[1:]}. Fares usually rise around school holidays and major festivals, so search flexible dates.</p>
<h2>Things to do in {d}</h2><ul>{"".join(f"<li>{x}</li>" for x in todo)}</ul>
<h2>Visa and entry</h2><p>{note}</p>
<h2>Frequently asked questions</h2>{"".join(f"<details><summary>{q}</summary><p>{a}</p></details>" for q,a in faq)}</article></div></section>'''
    page(f"/destinations/{s}",f"{h} – Fares, Flight Time & Best Season | Fareuno",f"{intro[:110].rstrip('. ')}. Flight time, best season, things to do and tips for flying Delhi to {d} ({c}).",body,
     extra=ld(crumbs(items),{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":q,"acceptedAnswer":{"@type":"Answer","text":a}} for q,a in faq]},
     {"@context":"https://schema.org","@type":"TouristDestination","name":d,"description":intro,"url":SITE+f"/destinations/{s}"}),prio="0.8")

# GUIDES
GUIDES=[("how-to-find-cheap-flights-from-india","How to Find Cheap Flights from India: 9 Practical Tips","Practical, no-gimmick ways to lower the price of international flights from Delhi, Mumbai and other Indian airports.",[
("Be flexible with dates","Fares can differ a lot between adjacent days. Compare a few departure dates before committing, and consider mid-week flights, which are often cheaper than weekends."),
("Compare non-stop and one-stop","One-stop itineraries via hubs such as Doha, Dubai or Singapore can cost less. Weigh the saving against the extra hours and the risk of a missed connection."),
("Book international trips early, but not blindly","For peak travel (Diwali, summer holidays, year-end) book well ahead. For off-peak travel, watching prices for a couple of weeks is reasonable."),
("Watch total cost, not just the fare","Baggage, seat selection and meals can add up on low-cost carriers. Compare what is included."),
("Check nearby airports","If you live near more than one airport, search both; the difference can cover the cost of travelling there."),
("Read the fare rules","Cheaper fares are often non-refundable or carry change fees. If your plans may move, a slightly higher flexible fare can be the better value.")]),
("international-flight-booking-checklist","International Flight Booking Checklist: Documents, Timing & Rules","A step-by-step checklist to run through before you pay for an international flight from India.",[
("Passport validity","Many countries require your passport to be valid for at least six months from the date of entry, and to have blank pages. Check the destination’s rule first."),
("Visa or e-visa","Confirm whether your destination needs a visa and how long it takes. Avoid paying for non-refundable flights until you know the timeline."),
("Name match","The name on your ticket must exactly match your passport. Fixing errors later can be costly."),
("Return or onward ticket","Some countries ask for proof of onward travel at check-in or on arrival."),
("Travel insurance","Compare medical and trip-cancellation cover, especially for long trips and destinations with high healthcare costs."),
("Baggage and check-in","Confirm checked and cabin baggage limits, and the airline’s online check-in window.")]),
("best-time-to-book-international-flights","Best Time to Book International Flights","How far ahead to book, which days tend to be cheaper, and when to wait.",[
("Peak seasons","Around Diwali, the summer school break and year-end, fares climb as seats sell. Booking earlier tends to help for these periods."),
("Off-peak travel","For shoulder-season trips, prices move less predictably. Track your route for a while to see its normal range."),
("Day of travel","Flying on Tuesdays, Wednesdays or Saturdays is often cheaper than Fridays and Sundays, though this varies by route."),
("Set a budget and act","Once you see a fare inside your budget on a route you are sure about, booking is usually better than waiting for a further drop.")])]
gc="".join(f'<a class="card link" href="/guides/{s}"><h2 style="font-size:1.35rem">{t}</h2><p class="muted">{d}</p></a>' for s,t,d,_ in GUIDES)
page("/guides","Travel Guides – Flight Tips for Indian Travellers | Fareuno","Practical guides on finding cheap flights, booking international trips and preparing documents.",
 f'{crumb_html([("Home","/"),("Travel guides","/guides")])}<section style="padding-top:10px"><div class="wrap"><h1>Travel guides</h1><div class="grid" style="margin-top:30px">{gc}</div></div></section>',extra=ld(crumbs([("Home","/"),("Travel guides","/guides")])),prio="0.7")
for s,t,d,secs in GUIDES:
    items=[("Home","/"),("Travel guides","/guides"),(t,f"/guides/{s}")]
    page(f"/guides/{s}",f"{t} | Fareuno",d,
     f'{crumb_html(items)}<section style="padding-top:10px"><div class="wrap"><article><h1>{t}</h1><p class="lead">{d}</p>'+"".join(f"<h2>{h}</h2><p>{p}</p>" for h,p in secs)+'<p><a class="btn" href="/#search">Search flights</a></p></article></div></section>',
     extra=ld(crumbs(items),{"@context":"https://schema.org","@type":"Article","headline":t,"description":d,"dateModified":TODAY,"author":{"@type":"Organization","name":NAME},"publisher":{"@type":"Organization","name":NAME},"mainEntityOfPage":SITE+f"/guides/{s}"}),prio="0.6",og="article")

# STATIC PAGES
def simple(path,title,desc,h1,html,prio="0.4"):
    page(path,f"{title} | Fareuno",desc,f'{crumb_html([("Home","/"),(h1,path)])}<section style="padding-top:10px"><div class="wrap"><article><h1>{h1}</h1>{html}</article></div></section>',extra=ld(crumbs([("Home","/"),(h1,path)])),prio=prio)
simple("/about","About Fareuno","Fareuno helps travellers from India compare flights with clear prices and practical guides.","About Fareuno","<p>Fareuno is a flight comparison and travel planning site built for travellers from India. Our aim is simple: show clear prices, make date flexibility easy and explain the practical things that trip planning involves.</p><p>We work with flight data providers to show available fares. Prices and availability change continuously and are confirmed at the time of booking.</p>","0.5")
simple("/contact","Contact Us","Contact Fareuno for help with a flight search or booking request.","Contact us","<p>Email us at <a href='mailto:hello@fareuno.com'>hello@fareuno.com</a> with your route, travel dates and number of travellers, and we will reply by email.</p>","0.5")
simple("/privacy","Privacy Policy","How Fareuno handles your information.","Privacy policy","<p>We collect only the information needed to run the site: the searches you make and any details you send us through email. We do not sell personal information. Replace this template with a policy reviewed by a qualified professional before launch, including any cookie and analytics disclosures that apply to you.</p>","0.2")
simple("/terms","Terms of Use","Terms for using Fareuno.","Terms of use","<p>Fares and availability shown on this site are provided by third parties, change quickly and are confirmed only at booking. Replace this template with terms reviewed by a qualified professional before launch.</p>","0.2")
page("/404","Page not found | Fareuno","This page could not be found.",'<section><div class="wrap"><h1>Page not found</h1><p>Try the <a href="/">homepage</a> or <a href="/flights">search flights</a>.</p></div></section>',noindex=True)

# ASSETS
open("assets/favicon.svg","w").write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0f3d33"/><path d="M14 38l36-18-10 28-8-10-10 6z" fill="#e8590c"/></svg>')
open("assets/og.svg","w").write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630"><rect width="1200" height="630" fill="#0f3d33"/><text x="80" y="300" font-family="Georgia,serif" font-size="110" fill="#faf7f2">Find the fare.</text><text x="80" y="430" font-family="Georgia,serif" font-size="110" fill="#e8590c">Skip the fuss.</text><text x="80" y="540" font-family="sans-serif" font-size="44" fill="#cfe0d9">Fareuno</text></svg>')
open("robots.txt","w").write(f"User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: {SITE}/sitemap.xml\n")
open("sitemap.xml","w").write('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+"".join(f"<url><loc>{SITE}{p if p!='/' else '/'}</loc><lastmod>{TODAY}</lastmod><priority>{pr}</priority></url>" for p,pr in pages)+"</urlset>")
print(len(pages),"pages")
