const AIRPORTS=[["DEL","Delhi"],["BOM","Mumbai"],["BLR","Bengaluru"],["HYD","Hyderabad"],["MAA","Chennai"],["CCU","Kolkata"],["GOI","Goa"],["DXB","Dubai"],["BKK","Bangkok"],["SIN","Singapore"],["LHR","London"],["JFK","New York"],["DOH","Doha"],["KUL","Kuala Lumpur"],["CDG","Paris"],["SYD","Sydney"],["YYZ","Toronto"],["SFO","San Francisco"]];
const $=s=>document.querySelector(s);
const code=v=>{v=(v||"").trim();const m=v.match(/\(([A-Z]{3})\)\s*$/i);if(m)return m[1].toUpperCase();if(/^[A-Za-z]{3}$/.test(v))return v.toUpperCase();const a=AIRPORTS.find(x=>x[1].toLowerCase()===v.toLowerCase());return a?a[0]:""};
const dl=document.getElementById("airports");
if(dl)dl.innerHTML=AIRPORTS.map(a=>`<option value="${a[1]} (${a[0]})">`).join("");
const iso=d=>d.toISOString().slice(0,10);
const form=document.getElementById("search");
if(form){
 const dep=form.date,ret=form.ret,t=new Date();
 dep.min=iso(t);const d=new Date(t);d.setDate(d.getDate()+30);if(!dep.value)dep.value=iso(d);
 const p=new URLSearchParams(location.search);
 for(const k of["from","to","date","ret","adults","cabin"])if(p.get(k)&&form[k]){form[k].value=(k==="from"||k==="to")?(AIRPORTS.find(a=>a[0]===p.get(k))?AIRPORTS.find(a=>a[0]===p.get(k))[1]+" ("+p.get(k)+")":p.get(k)):p.get(k)}
 form.addEventListener("submit",e=>{
  const f=code(form.from.value),to=code(form.to.value);
  if(!f||!to||f===to){e.preventDefault();alert("Please pick two different airports from the list.");return}
  e.preventDefault();
  const q=new URLSearchParams({from:f,to,date:form.date.value,adults:form.adults.value,cabin:form.cabin.value});
  if(form.ret.value)q.set("ret",form.ret.value);
  location.href="/flights?"+q;
 });
}
const out=document.getElementById("results");
if(out&&location.search){
 const q=new URLSearchParams(location.search);
 out.innerHTML='<p class="muted">Searching fares…</p>';
 fetch("/api/flights?"+q).then(r=>r.json()).then(d=>{
  if(d.error){out.innerHTML=`<p class="banner">${d.error}</p>`;return}
  const cur=d.currency||"INR";
  const fmt=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:cur,maximumFractionDigits:0}).format(n);
  let h=d.demo?'<p class="banner"><strong>Sample fares.</strong> Live pricing is not connected yet — these results are illustrative only.</p>':"";
  h+=d.offers.map(o=>`<div class="card offer"><div><strong>${o.airline}</strong> <span class="tag">${o.stops?o.stops+" stop"+(o.stops>1?"s":""):"Non-stop"}</span><br>${o.depart} → ${o.arrive} · ${o.duration}<br><span class="muted">${o.from} → ${o.to}</span></div><div style="text-align:right"><div class="price">${fmt(o.price)}</div><a class="btn" href="${o.link||"/contact?route="+o.from+"-"+o.to}">${o.link?"View deal":"Request fare"}</a></div></div>`).join("");
  out.innerHTML=h||"<p>No fares found for these dates. Try nearby dates.</p>";
 }).catch(()=>{out.innerHTML='<p class="banner">Search is unavailable right now. Please try again shortly.</p>'});
}
